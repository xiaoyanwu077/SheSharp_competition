### project idea: 
#### for new graduates and starters, job seeking are always confusing. The skills required at job market are not taught in school. Therefore, we want to come up with a wordcloud (most frequently wanted skills/tech stack) for each type of IT job. Having this as a reference, job seekers can have a more targeted preparation for the market. For those whose skill sets have already some overlapping with the market need, they can feed our wordcloud and their original cover letter to gpt to write a cover letter that has higher chance to pass the Application Tracking System


```python
from wordcloud import WordCloud, ImageColorGenerator, STOPWORDS
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import pandas as pd 
import matplotlib.pyplot as plt 
import seaborn as sns 
import numpy as np
```

### load the global job posting data set


```python
df_global = pd.read_csv('data/sourcestack-data-global.csv')
```


```python
df_global
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>job_name</th>
      <th>hours</th>
      <th>department</th>
      <th>seniority</th>
      <th>remote</th>
      <th>company_name</th>
      <th>company_url</th>
      <th>post_url</th>
      <th>tags_matched</th>
      <th>tag_categories</th>
      <th>job_location</th>
      <th>city</th>
      <th>region</th>
      <th>country</th>
      <th>last_indexed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Supplier Dev Engineer I</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Honeywell</td>
      <td>NaN</td>
      <td>honeywell.gr8people.com/jobs/124522/supplier-d...</td>
      <td>[Sigma]</td>
      <td>[Tools, Serverless]</td>
      <td>Location: Tempe, Arizona  US</td>
      <td>Tempe</td>
      <td>Arizona</td>
      <td>United States</td>
      <td>2023-05-29 05:05:30</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Java Frontend Developer</td>
      <td>Full-Time</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>False</td>
      <td>Sonsoft</td>
      <td>NaN</td>
      <td>jobs.smartrecruiters.com/sonsoftinc/100746099</td>
      <td>[Java, Bootstrap, Struts, Angular.js, SQL, Rea...</td>
      <td>[Libraries, Big Data Tools, JavaScript UI Libr...</td>
      <td>Milwaukee, WI</td>
      <td>Milwaukee</td>
      <td>Wisconsin</td>
      <td>United States</td>
      <td>2023-05-29 05:00:23</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Retail Front End Supervisor</td>
      <td>Full-Time</td>
      <td>NaN</td>
      <td>Manager</td>
      <td>NaN</td>
      <td>Burlington Stores</td>
      <td>NaN</td>
      <td>storeassociates-burlingtonstores.icims.com/job...</td>
      <td>[]</td>
      <td>[]</td>
      <td>Whitehall, Pennsylvania, United States</td>
      <td>Whitehall</td>
      <td>Pennsylvania</td>
      <td>United States</td>
      <td>2023-06-05 05:31:36</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Manager Software Engineering-Austin, Dallas, S...</td>
      <td>Full-Time</td>
      <td>Enterprise Engineering SA-EX</td>
      <td>Manager</td>
      <td>NaN</td>
      <td>H-E-B, L.P.</td>
      <td>NaN</td>
      <td>careers-heb.icims.com/jobs/46075/manager-softw...</td>
      <td>[]</td>
      <td>[]</td>
      <td>San Antonio, Texas, United States</td>
      <td>San Antonio</td>
      <td>Texas</td>
      <td>United States</td>
      <td>2023-06-05 05:31:30</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Security Officer- Unarmed</td>
      <td>Full-Time</td>
      <td>Security Officer</td>
      <td>Unclear Seniority</td>
      <td>NaN</td>
      <td>Brosnan Risk Consultants</td>
      <td>NaN</td>
      <td>hourly-brosnanrisk.icims.com/jobs/8489/securit...</td>
      <td>[]</td>
      <td>[]</td>
      <td>Greeley, Colorado, United States</td>
      <td>Greeley</td>
      <td>Colorado</td>
      <td>United States</td>
      <td>2023-06-05 10:26:02</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>495</th>
      <td>Client Transformation Site Reliability Enginee...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Kyndryl</td>
      <td>kyndryl.com</td>
      <td>krb-sjobs.brassring.com/tgnewui/search/home/ho...</td>
      <td>[Azure, Windows, Docker, Google Cloud, AWS, Li...</td>
      <td>[IaaS, OS, PaaS, Enterprise Software, SaaS, So...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2023-05-15 07:03:12</td>
    </tr>
    <tr>
      <th>496</th>
      <td>Full-stack Developer (Node.js)</td>
      <td>Full-Time</td>
      <td>Engineering – Frontend</td>
      <td>NaN</td>
      <td>True</td>
      <td>Binance</td>
      <td>binance.com</td>
      <td>jobs.lever.co/binance/5533a6c9-d5b5-4dad-820a-...</td>
      <td>[Blockchain, React, Vue.js, Angular.js, Webpac...</td>
      <td>[Templating Languages, OSS, JavaScript UI Libr...</td>
      <td>Asia</td>
      <td>Asia</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2023-06-06 20:57:11</td>
    </tr>
    <tr>
      <th>497</th>
      <td>Process Engineer (30521)</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>MAHLE Group</td>
      <td>mahle.com</td>
      <td>career5.successfactors.eu/career?career_ns=job...</td>
      <td>[]</td>
      <td>[]</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2023-05-31 18:09:31</td>
    </tr>
    <tr>
      <th>498</th>
      <td>Senior DevOps Engineer (123718)</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Senior IC</td>
      <td>NaN</td>
      <td>Swiss Re</td>
      <td>swissre.com</td>
      <td>career2.successfactors.eu/career?career_ns=job...</td>
      <td>[Magnum, Ansible, Jenkins, Kubernetes, Subvers...</td>
      <td>[Datastores, Provisioning, Big Data Tools, Pro...</td>
      <td>India</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>India</td>
      <td>2023-06-04 13:22:22</td>
    </tr>
    <tr>
      <th>499</th>
      <td>Azure Architect Engineer - Japanese Bilingual</td>
      <td>Contract</td>
      <td>NaN</td>
      <td>Junior IC</td>
      <td>NaN</td>
      <td>Cinter Career Services</td>
      <td>cinter.net</td>
      <td>cinter.applytojob.com/apply/2mTcm5fEoa/Azure-A...</td>
      <td>[PowerShell, C#, Microsoft, Azure]</td>
      <td>[Terminals, Programming Languages, Compute, OSS]</td>
      <td>Plano, TX</td>
      <td>Plano</td>
      <td>Texas</td>
      <td>United States</td>
      <td>2023-05-17 21:06:48</td>
    </tr>
  </tbody>
</table>
<p>500 rows × 15 columns</p>
</div>



### To do fuzzy matching for job name, we normalize the job name column by converting to lower case, removing tabulation, punctuation, and special characters.


```python
## Lower case
df_global['job_name'] = df_global['job_name'].apply(lambda x: " ".join(x.lower()for x in x.split()))
## remove tabulation and punctuation
df_global['job_name'] = df_global['job_name'].str.replace('[^\w\s]',' ')
## digits
df_global['job_name'] = df_global['job_name'].str.replace('\d+', '')
## remove -
df_global['job_name'] = df_global['job_name'].str.replace('-', '')
```

    /tmp/ipykernel_158641/1106077919.py:4: FutureWarning: The default value of regex will change from True to False in a future version.
      df_global['job_name'] = df_global['job_name'].str.replace('[^\w\s]',' ')
    /tmp/ipykernel_158641/1106077919.py:6: FutureWarning: The default value of regex will change from True to False in a future version.
      df_global['job_name'] = df_global['job_name'].str.replace('\d+', '')



```python
df_global['job_name'] = df_global['job_name'].str.replace('  ', ' ')
df_global['job_name'] = df_global['job_name'].str.replace('\n', ' ')
```

### We want to get job descriptions from job posting URL in the future, therefore we add https:// as prefix for all the url strings


```python
df_global['prefix']="https://"
df_global["prefix_url"]=df_global[["prefix","post_url"]].agg(''.join, axis=1)
df_global.drop(columns=['prefix', 'post_url'], inplace=True)
```

#### for this analysis, we ended up not using the url for scraping job description because a lot of url turns out to have "this job no longer exist". In the future if we are working with up-to-date (streaming) job posting, this will be very useful

### The tags_matched and tag_categories columns contain important skills or tech stacks wanted for the job, therefore, we want to scrap information from these two columns. We transform them into strings without special character. For empty string, we transform them to nan


```python
df_global['tags_matched'] = df_global['tags_matched'].str.strip("[]")
df_global['tag_categories'] = df_global['tag_categories'].str.strip("[]")
df_global = df_global.replace(r'^\s*$', np.nan, regex=True)
```

### We find the 12 "most common" tech jobs, parsing each of them into a pandas dataframe


```python
data_engineer_global = df_global[df_global['job_name'].str.contains("data engineer")]

data_scientist_global = df_global[df_global['job_name'].str.contains("data scientist")]

frontend_global = df_global[df_global['job_name'].str.contains("frontend|front end")]

backend_global = df_global[df_global['job_name'].str.contains("backend|front end")]

data_analyst_global = df_global[df_global['job_name'].str.contains("data analyst")]

full_stack_global = df_global[df_global['job_name'].str.contains("full stack|fullstack")]

product_manager_global = df_global[df_global['job_name'].str.contains("product manager")]

product_owner_global = df_global[df_global['job_name'].str.contains("product owner")]

quality_global = df_global[df_global['job_name'].str.contains("quality")]

support_global = df_global[df_global['job_name'].str.contains("support")]

devops_global = df_global[df_global['job_name'].str.contains("devops")]

security_engineer_global = df_global[df_global['job_name'].str.contains("security engineer")]
```

### Now we define a function that removes common English words and punctuation from tags and job descriptions


```python
stop_words = stopwords.words('english')
stop_words.extend(['tools'])

def punctuation_stop(text):
    """remove punctuation and stop words"""
    filtered = []
    word_tokens = word_tokenize(text)

    for w in word_tokens:
        if w not in stop_words and w.isalpha():
            filtered.append(w.lower())
    return filtered

```

### Now we create a word cloud for each of the 12 job titles, highlighting the most wanted skills and tech stack


```python
csv = [data_engineer_global, data_scientist_global, frontend_global, backend_global, data_analyst_global, 
full_stack_global, product_manager_global, product_owner_global, quality_global, support_global, 
devops_global, security_engineer_global]
```


```python
role_names = "data_engineer_global, data_scientist_global, frontend_global, backend_global, data_analyst_global, \
full_stack_global, product_manager_global, product_owner_global, quality_global, support_global, \
devops_global, security_engineer_global".split(", ")
```


```python
for role, role_name in zip(csv, role_names):
    role_pd = role[["tags_matched", "tag_categories"]].dropna()
    print("Our original data set for " + role_name + " has " + str(len(role)) + " entries")
    print("After cleaning, we are working with %d entries" %len(role_pd) )
    
    list_desc = ' '.join(role_pd.tags_matched.tolist() + 
                     role_pd.tag_categories.tolist())
    
    words_filtered = punctuation_stop(list_desc)

    text = " ".join([ele for ele in words_filtered])
    wc= WordCloud(background_color="white", random_state=1,stopwords=stop_words, max_words = 12, width =900, height = 600)
    wc.generate(text)

    plt.figure(figsize=[3,2])
    plt.imshow(wc,interpolation="bilinear")
    plt.axis('off')
    plt.title(role_name)
    plt.show()
```

    Our original data set for data_engineer_global has 8 entries
    After cleaning, we are working with 8 entries



    
![png](output_20_1.png)
    


    Our original data set for data_scientist_global has 3 entries
    After cleaning, we are working with 3 entries



    
![png](output_20_3.png)
    


    Our original data set for frontend_global has 12 entries
    After cleaning, we are working with 10 entries



    
![png](output_20_5.png)
    


    Our original data set for backend_global has 15 entries
    After cleaning, we are working with 12 entries



    
![png](output_20_7.png)
    


    Our original data set for data_analyst_global has 9 entries
    After cleaning, we are working with 8 entries



    
![png](output_20_9.png)
    


    Our original data set for full_stack_global has 21 entries
    After cleaning, we are working with 20 entries



    
![png](output_20_11.png)
    


    Our original data set for product_manager_global has 10 entries
    After cleaning, we are working with 7 entries



    
![png](output_20_13.png)
    


    Our original data set for product_owner_global has 4 entries
    After cleaning, we are working with 3 entries



    
![png](output_20_15.png)
    


    Our original data set for quality_global has 7 entries
    After cleaning, we are working with 7 entries



    
![png](output_20_17.png)
    


    Our original data set for support_global has 15 entries
    After cleaning, we are working with 13 entries



    
![png](output_20_19.png)
    


    Our original data set for devops_global has 13 entries
    After cleaning, we are working with 13 entries



    
![png](output_20_21.png)
    


    Our original data set for security_engineer_global has 8 entries
    After cleaning, we are working with 7 entries



    
![png](output_20_23.png)
    



```python

```


```python

```
